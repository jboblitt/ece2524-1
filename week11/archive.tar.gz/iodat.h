// iodat.h: Example interface file to demonstrate 'make'
using namespace std;
// member function
class ioClass
{
public:
    ioClass(const double v);
    double getval();
private:
    double value;
};
